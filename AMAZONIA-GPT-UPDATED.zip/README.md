# GPT-4 Chat App

A simple chat application using GPT-4-turbo with image analysis and tool integration.